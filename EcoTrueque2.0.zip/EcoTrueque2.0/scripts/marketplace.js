// === SIMULAR BASE DE DATOS DE PRODUCTOS EN LOCALSTORAGE ===
if (!localStorage.getItem('productos')) {
  const productos = [
    { id: 1, nombre: 'Botellas de Vidrio', precio: 230, imagen: 'images/products/producto1.jpeg', descripcion: 'Botellas de vidrio recicladas, perfectas para decoración o almacenamiento.', vendedor: { nombre: 'Ana López', avatar: 'images/products/avatar1.png', rating: '⭐⭐⭐⭐☆' }},
    { id: 2, nombre: 'Ropa Reciclada', precio: 230, imagen: 'images/products/producto2.jpeg', descripcion: 'Ropa usada en excelente estado, lavada y revisada.', vendedor: { nombre: 'Carlos Ruiz', avatar: 'images/products/avatar2.png', rating: '⭐⭐⭐⭐⭐' }},
    { id: 3, nombre: 'Cartón Reciclado', precio: 230, imagen: 'images/products/producto3.jpeg', descripcion: 'Cartón limpio y seco, ideal para manualidades o empaques.', vendedor: { nombre: 'María García', avatar: 'images/products/avatar3.png', rating: '⭐⭐⭐⭐☆' }},
    { id: 4, nombre: 'Caja de Madera', precio: 230, imagen: 'images/products/producto4.jpeg', descripcion: 'Caja de madera reciclada, resistente y decorativa.', vendedor: { nombre: 'Jorge Pérez', avatar: 'images/products/avatar4.png', rating: '⭐⭐⭐⭐☆' }},
    { id: 5, nombre: 'Componentes Electrónicos', precio: 230, imagen: 'images/products/producto5.jpeg', descripcion: 'Componentes electrónicos usados pero funcionales.', vendedor: { nombre: 'Luis Martínez', avatar: 'images/products/avatar5.png', rating: '⭐⭐⭐⭐☆' }},
    { id: 6, nombre: 'Tapetes de Plástico', precio: 230, imagen: 'images/products/producto6.jpeg', descripcion: 'Tapetes hechos de plástico reciclado, resistentes al agua.', vendedor: { nombre: 'Sofía Torres', avatar: 'images/products/avatar6.png', rating: '⭐⭐⭐⭐⭐' }},
    { id: 7, nombre: 'Macetas de Cerámica', precio: 230, imagen: 'images/products/producto7.jpeg', descripcion: 'Macetas de cerámica reciclada, ideales para plantas pequeñas.', vendedor: { nombre: 'Pedro Sánchez', avatar: 'images/products/avatar7.png', rating: '⭐⭐⭐⭐☆' }},
    { id: 8, nombre: 'Papel Reciclado', precio: 230, imagen: 'images/products/producto8.jpeg', descripcion: 'Papel reciclado de alta calidad, ideal para impresión o escritura.', vendedor: { nombre: 'Laura Fernández', avatar: 'images/products/avatar8.png', rating: '⭐⭐⭐⭐⭐' }},
    { id: 9, nombre: 'Cables Reutilizados', precio: 230, imagen: 'images/products/producto9.jpeg', descripcion: 'Cables eléctricos reutilizados, probados y seguros.', vendedor: { nombre: 'Daniel Gómez', avatar: 'images/products/avatar9.png', rating: '⭐⭐⭐⭐☆' }},
    { id: 10, nombre: 'Bolsas de Tela', precio: 230, imagen: 'images/products/producto10.jpeg', descripcion: 'Bolsas de tela reutilizables, ecológicas y duraderas.', vendedor: { nombre: 'Isabel Díaz', avatar: 'images/products/avatar10.png', rating: '⭐⭐⭐⭐⭐' }}
  ];
  localStorage.setItem('productos', JSON.stringify(productos));
}

// === SIMULAR CARRITO DE COMPRAS ===
if (!localStorage.getItem('carrito')) {
  localStorage.setItem('carrito', JSON.stringify([]));
}

// === ABRIR MODAL DE PRODUCTO ===
function abrirModalProducto(id) {
  const productos = JSON.parse(localStorage.getItem('productos')) || [];
  const producto = productos.find(p => p.id === id);

  if (!producto) return;

  // Crear el modal
  const modal = document.createElement('div');
  modal.className = 'product-modal';
  modal.innerHTML = `
    <div class="product-modal-content">
      <!-- X en esquina superior izquierda -->
      <span class="close-btn" onclick="this.parentElement.parentElement.remove()">&times;</span>
      
      <!-- Corazón en esquina superior derecha -->
      <div class="heart-icon-container">
        <div class="heart-icon" data-id="${producto.id}" onclick="toggleFavorito(this)">♡</div>
      </div>

      <div class="product-image-large">
        <img src="${producto.imagen}" alt="${producto.nombre}">
      </div>
      <div class="product-info">
        <h1>${producto.nombre}</h1>
        <div class="product-price">$${producto.precio}</div>
        <div class="product-stats">
          <span>⭐⭐⭐⭐☆</span>
          <span>360 items sold</span>
        </div>
        <div class="product-description">
          <p>${producto.descripcion}</p>
        </div>
        <div class="product-actions">
          <!-- ⛔ QUITAMOS EL BOTÓN DE COMPRAR -->
          <button class="btn btn-secondary">Trueque</button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
}

// === TOGGLE FAVORITO ===
function toggleFavorito(corazon) {
  corazon.classList.toggle('favorito');
  if (corazon.classList.contains('favorito')) {
    mostrarNotificacion('❤️ Producto marcado como favorito');
  } else {
    mostrarNotificacion('🤍 Producto desmarcado de favoritos');
  }
}

// === MOSTRAR NOTIFICACIÓN ===
function mostrarNotificacion(mensaje) {
  alert(mensaje); // ← Puedes cambiar por un toast si quieres que se vea más bonito
}

// === AGREGAR AL CARRITO ===
function agregarAlCarrito(nombre, precio) {
  const producto = { nombre, precio };
  const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
  const existe = carrito.some(item => item.nombre === nombre);

  if (!existe) {
    carrito.push(producto);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    actualizarContadorCarrito();
    mostrarNotificacion('✅ Producto agregado al carrito');
  } else {
    mostrarNotificacion('⚠️ El producto ya está en el carrito');
  }
}

// === ACTUALIZAR CONTADOR DEL CARRITO ===
function actualizarContadorCarrito() {
  const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
  const contador = document.getElementById('cartBadge');
  const cantidad = carrito.length;

  if (cantidad > 0) {
    contador.textContent = cantidad;
    contador.style.opacity = '1';
  } else {
    contador.style.opacity = '0';
  }
}

// === CARGAR PRODUCTOS DESDE LOCALSTORAGE ===
function cargarProductos(categoria = 'all', gridId = 'productGrid') {
  const productos = JSON.parse(localStorage.getItem('productos')) || [];
  const grid = document.getElementById(gridId);
  grid.innerHTML = ''; // ← Limpiar contenido actual

  const productosFiltrados = categoria === 'all' ? productos : productos.filter(p => p.categoria === categoria);

  productosFiltrados.forEach(producto => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => abrirModalProducto(producto.id); // ← Abrir modal al hacer clic en la tarjeta
    card.innerHTML = `
      <div class="product-image">
        <img src="${producto.imagen}" alt="${producto.nombre}">
      </div>
      <div class="product-info">
        <div class="product-title">${producto.nombre}</div>
        <div class="product-price">$${producto.precio}</div>
        <div class="product-stats">
          <span>⭐⭐⭐⭐☆</span>
          <span>${producto.vendidos} items sold</span>
        </div>
        <div class="heart-icon" data-id="${producto.id}" onclick="toggleFavorito(this)">♡</div>
      </div>
    `;
    grid.appendChild(card);
  });
}

// === FILTRAR POR CATEGORÍA ===
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', function() {
    const categoria = this.getAttribute('data-category');
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    this.classList.add('active');
    cargarProductos(categoria, 'productGrid'); // ← Cargar en primera categoría
    cargarProductos(categoria, 'productGrid2'); // ← Cargar en segunda categoría
  });
});

// === CERRAR SESIÓN ===
document.getElementById('logoutBtn').addEventListener('click', function() {
  localStorage.removeItem('usuarioActivo'); // ← Eliminar sesión
  window.location.href = 'index.html'; // ← Redirigir al login
});

// === TOGGLE SIDEBAR ===
const botonMenu = document.getElementById('menuToggle');
const barraLateral = document.getElementById('sidebar');
const contenidoPrincipal = document.getElementById('mainContent');

botonMenu.addEventListener('click', function() {
  this.classList.toggle('active');
  barraLateral.classList.toggle('open');
  contenidoPrincipal.classList.toggle('sidebar-open');
});

// === TOGGLE PERFIL DROPDOWN ===
const botonPerfil = document.getElementById('profileIcon');
const dropdownPerfil = document.getElementById('profileDropdown');

botonPerfil.addEventListener('click', function() {
  dropdownPerfil.classList.toggle('open');
});

document.addEventListener('click', function(event) {
  if (!botonPerfil.contains(event.target) && !dropdownPerfil.contains(event.target)) {
    dropdownPerfil.classList.remove('open');
  }
});

// === ANIMACIÓN DEL CARRITO (CREATIVA Y BONITA) ===
const botonCarrito = document.getElementById('cartButton');
const contadorCarrito = document.getElementById('cartBadge');

botonCarrito.addEventListener('mouseenter', function() {
  this.style.transform = 'scale(1.1) translateY(-5px)';
  this.style.backgroundColor = '#45a049';
  contadorCarrito.style.opacity = '1';
});

botonCarrito.addEventListener('mouseleave', function() {
  this.style.transform = 'scale(1)';
  this.style.backgroundColor = 'var(--primary-green)';
  contadorCarrito.style.opacity = '0';
});

botonCarrito.addEventListener('click', function() {
  this.style.animation = 'none';
  setTimeout(() => {
    this.style.animation = 'pulse 2s infinite';
  }, 10);
  const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
  mostrarNotificacion('🛒 Tu carrito tiene ' + carrito.length + ' productos');
});

// === ACTUALIZAR BADGE DEL CARRITO ===
function actualizarBadgeCarrito() {
  const carrito = JSON.parse(localStorage.getItem('carrito')) || [];
  const badge = document.getElementById('cartBadge');
  const count = carrito.length;

  if (count > 0) {
    badge.textContent = count;
    badge.style.opacity = '1';
  } else {
    badge.style.opacity = '0';
  }
}

// === CARGAR AL INICIAR ===
document.addEventListener('DOMContentLoaded', function() {
  cargarProductos(); // ← Cargar productos al inicio
  cargarProductos('all', 'productGrid2'); // ← Cargar en segunda categoría también
  actualizarBadgeCarrito(); // ← Actualizar contador del carrito

  // === NOTIFICACIONES (CAMPAÑITA) ===
  const botonNotificaciones = document.querySelector('.header-icons .icon:first-child'); // ← Campanita
  const dropdownNotificaciones = document.createElement('div');
  dropdownNotificaciones.className = 'notification-dropdown';
  dropdownNotificaciones.innerHTML = `
    <ul>
      <li>📦 Tu pedido ha sido enviado</li>
      <li>✅ Transacción completada</li>
      <li>🔔 Recordatorio: Revisa tu perfil</li>
      <li>🌿 ¡Nueva categoría disponible!</li>
      <li>♻️ Recuerda reciclar</li>
    </ul>
  `;

  // Añadir dropdown al body
  document.body.appendChild(dropdownNotificaciones);

  // Toggle dropdown de notificaciones
  botonNotificaciones.addEventListener('click', function() {
    dropdownNotificaciones.classList.toggle('open');
  });

  // Cerrar dropdown al hacer clic fuera
  document.addEventListener('click', function(event) {
    if (!botonNotificaciones.contains(event.target) && !dropdownNotificaciones.contains(event.target)) {
      dropdownNotificaciones.classList.remove('open');
    }
  });
});

// Animación de pulso (CSS)
const estilo = document.createElement('style');
estilo.textContent = `
  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
  }

  /* ===== MODAL DE PRODUCTO ===== */
  .product-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .product-modal-content {
    background-color: white;
    border-radius: 15px;
    padding: 20px;
    width: 500px;
    max-width: 90vw;
    position: relative;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  }

  .close-btn {
    position: absolute;
    top: 10px;
    left: 10px;
    font-size: 30px;
    cursor: pointer;
    color: #999;
    background: none;
    border: none;
    z-index: 10;
  }

  .heart-icon-container {
    position: absolute;
    top: 10px;
    right: 10px;
    z-index: 10;
  }

  .heart-icon {
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  .heart-icon.favorito {
    color: #FFD700;
  }

  .product-image-large img {
    width: 100%;
    height: auto;
    border-radius: 10px;
  }

  .product-info h1 {
    font-size: 24px;
    margin: 10px 0;
  }

  .product-price {
    font-size: 20px;
    color: #4CAF50;
    font-weight: bold;
    margin: 10px 0;
  }

  .product-stats {
    display: flex;
    gap: 10px;
    margin: 10px 0;
    font-size: 14px;
    color: #666;
  }

  .product-description {
    margin: 15px 0;
    font-size: 16px;
    color: #555;
  }

  .product-actions {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    justify-content: center; /* ← Centrar el botón */
  }

  .btn {
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.2s;
  }

  /* ⛔ QUITAMOS ESTILO DE BOTÓN DE COMPRAR */
  .btn-secondary {
    background-color: #4CAF50;
    color: white;
  }

  .btn:hover {
    opacity: 0.9;
    transform: translateY(-2px);
  }

  /* ===== NOTIFICATION DROPDOWN ===== */
  .notification-dropdown {
    position: absolute;
    top: 50px;
    right: 20px;
    background-color: white;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    width: 300px;
    z-index: 998;
    transform: scaleY(0);
    transform-origin: top;
    transition: transform 0.3s ease;
    opacity: 0;
  }

  .notification-dropdown.open {
    transform: scaleY(1);
    opacity: 1;
  }

  .notification-dropdown ul {
    list-style: none;
    padding: 15px;
  }

  .notification-dropdown li {
    padding: 10px 15px;
    cursor: pointer;
    border-radius: 6px;
    transition: background-color 0.2s;
  }

  .notification-dropdown li:hover {
    background-color: #f5f5f5;
  }
`;
document.head.appendChild(estilo);