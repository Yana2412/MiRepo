// === SIMULACIÓN DE USUARIOS EN LOCALSTORAGE ===
if (!localStorage.getItem('usuarios')) {
  localStorage.setItem('usuarios', JSON.stringify([]));
}

// === PANEL LATERAL IZQUIERDO ===
const toggleBtn = document.getElementById('toggleBtn');
const infoPanel = document.getElementById('infoPanel');
const closeBtn = document.getElementById('closeBtn');

toggleBtn.addEventListener('click', function() {
  infoPanel.classList.add('open');
});

closeBtn.addEventListener('click', function() {
  infoPanel.classList.remove('open');
});

document.addEventListener('click', function(event) {
  if (!infoPanel.contains(event.target) && event.target !== toggleBtn) {
    infoPanel.classList.remove('open');
  }
});

infoPanel.addEventListener('click', function(event) {
  event.stopPropagation();
});

// === MODAL DE REGISTRO ===
const openRegisterModal = document.getElementById('openRegisterModal');

openRegisterModal.addEventListener('click', async function() {
  try {
    const response = await fetch('modals/register.html');
    const html = await response.text();
    document.getElementById('registerModalContainer').innerHTML = html;

    setTimeout(() => {
      const modal = document.querySelector('#registerModalContainer .register-modal');
      if (modal) {
        modal.style.display = 'flex';
        initRegisterEvents(); // ← Inicializa eventos del registro
      }
    }, 10);
  } catch (error) {
    console.error('Error al cargar el modal de registro:', error);
  }
});

// === MODAL DE INICIO DE SESIÓN ===
const openLoginModal = document.getElementById('openLoginModal');

openLoginModal.addEventListener('click', async function() {
  try {
    const response = await fetch('modals/login.html');
    const html = await response.text();
    document.getElementById('loginModalContainer').innerHTML = html;

    setTimeout(() => {
      const modal = document.querySelector('#loginModalContainer .modal-overlay');
      if (modal) {
        modal.style.display = 'flex';
        initLoginEvents(); // ← Inicializa eventos del login
      }
    }, 10);
  } catch (error) {
    console.error('Error al cargar el modal de login:', error);
  }
});

// === CERRAR MODAL DE INICIO DE SESIÓN ===
document.addEventListener('click', function(event) {
  if (event.target.id === 'closeLoginModal') {
    const loginModal = document.querySelector('#loginModalContainer .modal-overlay');
    if (loginModal) {
      loginModal.style.display = 'none';
    }
  }

  // === CERRAR MODAL DE REGISTRO ===
  if (event.target.id === 'closeRegisterModal') {
    const registerModal = document.querySelector('#registerModalContainer .register-modal');
    if (registerModal) {
      registerModal.style.display = 'none';
    }
  }
});

// Cerrar modales al hacer clic fuera
document.addEventListener('click', function(event) {
  const loginModal = document.querySelector('#loginModalContainer .modal-overlay');
  const registerModal = document.querySelector('#registerModalContainer .register-modal');

  if (loginModal && event.target === loginModal) {
    loginModal.style.display = 'none';
  }

  if (registerModal && event.target === registerModal) {
    registerModal.style.display = 'none';
  }
});

// === FUNCIONES DE VALIDACIÓN ===
const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

const validatePhone = (phone) => {
  const re = /^\d{10}$/;
  return re.test(phone);
};

const validateName = (name) => {
  const re = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;
  return re.test(name);
};

// === INICIO DE SESIÓN SIMULADO ===
function initLoginEvents() {
  const loginForm = document.getElementById('loginForm');
  if (!loginForm) return;

  loginForm.addEventListener('submit', async function(e) {
    e.preventDefault(); // ← Previene recargar la página

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const loginSpinner = document.getElementById('loginSpinner');
    const loginButton = document.querySelector('#loginForm .btn-modal');
    const messageDiv = document.getElementById('message');

    // Validaciones
    if (!email) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Por favor, ingresa tu correo.';
      return;
    }

    if (!validateEmail(email)) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Correo inválido.';
      return;
    }

    if (password.length < 6) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'La contraseña debe tener al menos 6 caracteres.';
      return;
    }

    // Mostrar spinner y deshabilitar botón
    loginSpinner.style.display = 'inline-block';
    loginButton.disabled = true;

    // Obtener usuarios desde localStorage
    const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

    // Buscar usuario
    const usuario = usuarios.find(u => u.correo === email && u.contrasena === password);

    if (usuario) {
      messageDiv.className = 'success';
      messageDiv.innerHTML = '¡Inicio de sesión exitoso!';

      // ✅ REDIRECCIONAR A MARKETPLACE.HTML
      setTimeout(() => {
        window.location.href = 'marketplace.html'; // ← Cambia por tu archivo real
      }, 1500);

    } else {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Error: Correo o contraseña incorrectos.';
    }

    // Ocultar spinner y habilitar botón
    loginSpinner.style.display = 'none';
    loginButton.disabled = false;
  });

  // === CAMBIAR A REGISTRO ===
  const switchToRegister = document.getElementById('switchToRegister');
  if (switchToRegister) {
    switchToRegister.addEventListener('click', function(e) {
      e.preventDefault();
      const loginModal = document.querySelector('#loginModalContainer .modal-overlay');
      if (loginModal) {
        loginModal.style.display = 'none';
      }
      loadAndShowModal('register'); // ← Carga el modal de registro
    });
  }
}

// === REGISTRO SIMULADO ===
function initRegisterEvents() {
  const registerForm = document.getElementById('registerForm');
  if (!registerForm) return;

  registerForm.addEventListener('submit', function(e) {
    e.preventDefault(); // ← Previene recargar la página

    const nombre = document.getElementById('nombre').value.trim();
    const apellidoPaterno = document.getElementById('apellidoPaterno').value.trim();
    const apellidoMaterno = document.getElementById('apellidoMaterno').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const fechaNacimiento = document.getElementById('fechaNacimiento').value;
    const sexo = document.getElementById('sexo').value;
    const telefono = document.getElementById('telefono').value.trim();
    const direccion = document.getElementById('direccion').value.trim();

    const registerSpinner = document.getElementById('registerSpinner');
    const registerButton = document.querySelector('#registerForm .btn-modal');
    const messageDiv = document.getElementById('message'); // ← Reutilizamos el mismo div

    // Validaciones
    if (!nombre || !apellidoPaterno || !apellidoMaterno || !email || !password || !confirmPassword || !fechaNacimiento || !sexo || !telefono || !direccion) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Por favor, completa todos los campos.';
      return;
    }

    if (!validateName(nombre)) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Nombre inválido (solo letras y espacios).';
      return;
    }

    if (!validateName(apellidoPaterno)) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Apellido Paterno inválido (solo letras y espacios).';
      return;
    }

    if (!validateName(apellidoMaterno)) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Apellido Materno inválido (solo letras y espacios).';
      return;
    }

    if (!validateEmail(email)) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Correo inválido.';
      return;
    }

    if (password.length < 6) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'La contraseña debe tener al menos 6 caracteres.';
      return;
    }

    if (password !== confirmPassword) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Las contraseñas no coinciden.';
      return;
    }

    if (!validatePhone(telefono)) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Teléfono inválido (debe tener 10 dígitos).';
      return;
    }

    if (direccion.length < 10) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Dirección muy corta.';
      return;
    }

    // Validar fecha de nacimiento (no puede ser futura)
    const today = new Date().toISOString().split('T')[0];
    if (fechaNacimiento > today) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Fecha de nacimiento no puede ser futura.';
      return;
    }

    // Mostrar spinner y deshabilitar botón
    registerSpinner.style.display = 'inline-block';
    registerButton.disabled = true;

    // Obtener usuarios desde localStorage
    const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

    // Verificar si el correo ya existe
    const existeUsuario = usuarios.some(u => u.correo === email);

    if (existeUsuario) {
      messageDiv.className = 'error';
      messageDiv.innerHTML = 'Error: El correo ya está registrado.';
    } else {
      // Crear nuevo usuario
      const nuevoUsuario = {
        id: Date.now(), // ID único
        nombre,
        apellidoPaterno,
        apellidoMaterno,
        correo: email,
        contrasena: password, // En una simulación, no encriptamos
        fechaNacimiento,
        sexo,
        telefono,
        direccion
      };

      // Agregar nuevo usuario a la lista
      usuarios.push(nuevoUsuario);

      // Guardar usuarios actualizados en localStorage
      localStorage.setItem('usuarios', JSON.stringify(usuarios));

      messageDiv.className = 'success';
      messageDiv.innerHTML = '¡Registro exitoso!';

      // Redirigir a la pantalla principal después de 1.5 segundos
      setTimeout(() => {
        window.location.href = 'marketplace.html'; // ← Cambia por tu archivo real
      }, 1500);
    }

    // Ocultar spinner y habilitar botón
    registerSpinner.style.display = 'none';
    registerButton.disabled = false;
  });

  // === CAMBIAR A INICIO DE SESIÓN ===
  const switchToLogin = document.getElementById('switchToLogin');
  if (switchToLogin) {
    switchToLogin.addEventListener('click', function(e) {
      e.preventDefault();
      const registerModal = document.querySelector('#registerModalContainer .register-modal');
      if (registerModal) {
        registerModal.style.display = 'none';
      }
      loadAndShowModal('login'); // ← Carga el modal de login
    });
  }
}

// === CARGAR Y MOSTRAR MODALES DINÁMICAMENTE ===
async function loadAndShowModal(modalName) {
  try {
    const response = await fetch(`modals/${modalName}.html`);
    const html = await response.text();

    if (modalName === 'login') {
      document.getElementById('loginModalContainer').innerHTML = html;
      setTimeout(() => {
        const modal = document.querySelector('#loginModalContainer .modal-overlay');
        if (modal) {
          modal.style.display = 'flex';
          initLoginEvents(); // ← Inicializa eventos del login
        }
      }, 10);
    } else if (modalName === 'register') {
      document.getElementById('registerModalContainer').innerHTML = html;
      setTimeout(() => {
        const modal = document.querySelector('#registerModalContainer .register-modal');
        if (modal) {
          modal.style.display = 'flex';
          initRegisterEvents(); // ← Inicializa eventos del registro
        }
      }, 10);
    }
  } catch (error) {
    console.error('Error al cargar el modal:', error);
  }
}